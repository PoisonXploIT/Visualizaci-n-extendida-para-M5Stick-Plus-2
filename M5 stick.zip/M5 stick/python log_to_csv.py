import csv
import re
from datetime import datetime

log_file = "wifi_scan_evil.log"
csv_file = "wifi_scan_parsed.csv"

# Expresiones regulares
regex_red = re.compile(r"\[(.*?)\] (.+) \(([\da-f:]+)\) on channel (\d+) has (\d+) clients:")
regex_cliente = re.compile(r"\[(.*?)\] - ([\da-f:]+)")

# Lista para guardar las filas
registros = []

# Variables temporales
red_actual = None

with open(log_file, "r", encoding="utf-8") as f:
    for linea in f:
        linea = linea.strip()

        # Coincide con una nueva red WiFi
        match_red = regex_red.match(linea)
        if match_red:
            hora, ssid, bssid, canal, n_clientes = match_red.groups()
            red_actual = {
                "timestamp": hora,
                "ssid": ssid,
                "bssid": bssid,
                "canal": canal,
                "n_clientes": int(n_clientes),
                "clientes": []
            }
            continue

        # Coincide con un cliente conectado
        match_cliente = regex_cliente.match(linea)
        if match_cliente and red_actual:
            hora, mac_cliente = match_cliente.groups()
            red_actual["clientes"].append(mac_cliente)

            # Cuando ya tenemos todos los clientes esperados, guardamos y reiniciamos
            if len(red_actual["clientes"]) == red_actual["n_clientes"]:
                for cliente in red_actual["clientes"]:
                    registros.append({
                        "timestamp": red_actual["timestamp"],
                        "ssid": red_actual["ssid"],
                        "bssid": red_actual["bssid"],
                        "canal": red_actual["canal"],
                        "cliente_mac": cliente
                    })
                red_actual = None

# Escribir el archivo CSV
with open(csv_file, "w", newline="", encoding="utf-8") as csvfile:
    fieldnames = ["timestamp", "ssid", "bssid", "canal", "cliente_mac"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for fila in registros:
        writer.writerow(fila)

print(f"✅ CSV generado: {csv_file}")
