import requests
from datetime import datetime
import time

# URL de la interfaz web
url = "http://192.168.1.132:5000"
# Intervalo entre capturas (en segundos)
intervalo = 60  # cada 1 minuto

while True:
    try:
        response = requests.get(url)
        html = response.text

        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        nombre_archivo = f"respaldo_scan_{timestamp}.html"

        with open(nombre_archivo, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"[✔] Guardado {nombre_archivo}")
    except Exception as e:
        print(f"[✖] Error: {e}")

    time.sleep(intervalo)
