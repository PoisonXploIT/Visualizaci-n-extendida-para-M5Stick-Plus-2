import serial
from datetime import datetime

# CAMBIA ESTE PUERTO 
puerto = "COM4"
baud = 115200
ruta_log = "wifi_scan_evil.log"

with serial.Serial(puerto, baud, timeout=1) as ser:
    with open(ruta_log, "a", encoding="utf-8") as log:
        while True:
            linea = ser.readline().decode("utf-8", errors="ignore").strip()
            if linea:
                timestamp = datetime.now().strftime("%H:%M:%S")
                log.write(f"[{timestamp}] {linea}\n")
                log.flush()
                print(f"[{timestamp}] {linea}")
