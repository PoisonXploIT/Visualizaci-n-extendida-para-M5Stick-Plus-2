from flask import Flask, render_template_string
import os

app = Flask(__name__)
LOG_PATH = "wifi_scan_evil.log"

HTML = """
<!doctype html>
<html>
<head>
    <title>M5Stick Monitor</title>
    <meta http-equiv="refresh" content="2">
    <style>
        body { background-color: #111; color: #0f0; font-family: monospace; padding: 1rem; }
        pre { white-space: pre-wrap; word-wrap: break-word; }
    </style>
</head>
<body>
    <h2>M5Stick Console View</h2>
    <pre>{{ content }}</pre>
</body>
</html>
"""

@app.route("/")
def index():
    if os.path.exists(LOG_PATH):
        with open(LOG_PATH, "r", encoding="utf-8") as f:
            contenido = f.read()[-5000:]
    else:
        contenido = "Esperando datos..."
    return render_template_string(HTML, content=contenido)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
